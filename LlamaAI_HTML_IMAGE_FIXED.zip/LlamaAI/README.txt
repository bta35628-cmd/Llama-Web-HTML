LlamaAI HTML fixed
- Default language: English
- Choose language: English / Tiếng Việt
- Chat API: https://cj2api.keh5.workers.dev/v1/chat/completions
- Model: llama3.1-8B
- Uses Authorization: Bearer any (dummy key; the CJ2API project documents that any string can be used)
- History: localStorage
Open index.html in Chrome/Edge.
If the browser reports a CORS error, the endpoint must allow the page origin; no HTML-only app can bypass browser CORS.

Image upload: use 📎 Attach image, choose an image, or paste an image from the clipboard. The request uses OpenAI-compatible image_url content; image understanding depends on the selected model/API supporting vision.
