LlamaAI HTML image UI

Features:
- Image button is fixed at the bottom-left of the composer.
- Image preview appears inside the message box.
- Clipboard image paste is supported.
- Image requests use OpenAI-compatible image_url content parts.
- The current endpoint exposes llama3.1-8B. That listed model is a text model, so actual image understanding depends on whether the remote provider accepts vision content for that model; the client does not falsely claim vision support.
- Language selector: English / Tiếng Việt / 中文.
